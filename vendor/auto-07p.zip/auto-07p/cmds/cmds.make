#===> cmds.make
#
#   Makefile written by Xianjun WANG in March 1994
#
#   This Makefile is used under command mode
#
#   EQUATION_NAME      :     AUTO-Equation name
#
.IGNORE:
.SUFFIXES: .f90
#
CC    	   = gcc
FC    	   = gfortran
CFLAGS 	   = -g -O -I$(AUTO_DIR)/include
FFLAGS 	   = -g -fopenmp
OPT    	   = -O
SRC        = $(EQUATION_NAME).f
OBJ        = $(EQUATION_NAME).o
EXE        = $(EQUATION_NAME).exe
LIBS       = $(AUTO_DIR)/lib/*.o
RM         = rm -f
# @rn
run: $(EXE)
	@echo "Starting $(EQUATION_NAME) ..."
	@$(AUTO_COMMAND_PREFIX) ./$(EXE)
	@rm -f fort.2 fort.3
	@echo "$(EQUATION_NAME) ... done"
#
$(EXE): $(OBJ) $(LIBS)
	@if [ -f $(EQUATION_NAME).f90 -o -f $(EQUATION_NAME).f ]; then \
	  echo $(FC) $(FFLAGS) $(OPT) $(OBJ) -o $@ '$(LIBS)'; \
	  $(FC) $(FFLAGS) $(OPT) $(OBJ) -o $@ $(LIBS); \
	elif [ -f $(EQUATION_NAME).c ]; then \
	  echo $(FC) -L$(AUTO_DIR)/lib $(FFLAGS) $(OPT) $(OBJ) -o $@ '$(LIBS)' -lauto_c; \
	  $(FC) -L$(AUTO_DIR)/lib $(FFLAGS) $(OPT) $(OBJ) -o $@ $(LIBS) -l auto_c; \
	else \
	  echo $(EQUATION_NAME).f does not exist.; \
	fi
#
.f.o:
	$(FC) $(FFLAGS) $(OPT) -c $< -o $@
#
.f90.o:
	$(FC) $(FFLAGS) $(OPT) -c $< -o $@
#
.c.o:
	@if [ -f $(EQUATION_NAME).f90 ]; then \
	  echo $(FC) $(FFLAGS) $(OPT) -c $(EQUATION_NAME).f90 -o $@; \
	  $(FC) $(FFLAGS) $(OPT) -c $(EQUATION_NAME).f90 -o $@; \
	elif [ -f $(EQUATION_NAME).f ]; then \
	  echo $(FC) $(FFLAGS) $(OPT) -c $(EQUATION_NAME).f -o $@; \
	  $(FC) $(FFLAGS) $(OPT) -c $(EQUATION_NAME).f -o $@; \
	else \
	  echo $(CC) $(CFLAGS) $(OPT) -c $< -o $@; \
	  $(CC) $(CFLAGS) $(OPT) -c $< -o $@; \
	fi
#
$(EQUATION_NAME).o: $(AUTO_DIR)/include/auto_f2c.h
#
FLAGS=-I$(AUTO_DIR)/include $(OPT)
FCON=$(AUTO_DIR)/src/fcon.f
fcon: $(EQUATION_NAME).o $(AUTO_DIR)/src/fcon.f $(AUTO_DIR)/include/fcon.h
	@if [ -f $(EQUATION_NAME).f90 ]; then \
	  $(FC) $(FLAGS) $(FFLAGS) $(EQUATION_NAME).o $(FCON) -o $@; \
	elif [ -f $(EQUATION_NAME).f ]; then \
	  $(FC) $(FLAGS) $(FFLAGS) $(EQUATION_NAME).o $(FCON) -o $@; \
	elif [ -f $(EQUATION_NAME).c ]; then \
	  $(FC) -L$(AUTO_DIR)/lib $(FFLAGS) $(OPT) $(EQUATION_NAME).o $(FCON) -o $@ -lauto_c; \
	fi
#
# DO NOT ADD ANYTHING AFTER THIS LINE
#
